package com.fenix.datafit1.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fenix.datafit1.ui.theme.*

@Composable
fun ExcelImportScreen(
    isSpanish: Boolean,
    onBack: () -> Unit,
    onFileSelected: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        // ============================================
        // HEADER
        // ============================================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Text(
                text = "ANALYTICA SCIENTIFIC",
                style = MaterialTheme.typography.labelMedium,
                color = CobaltBlue,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSpanish) "Importar desde Excel"
                else "Import from Excel",
                style = MaterialTheme.typography.headlineSmall,
                color = GraphiteDark,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSpanish)
                    "Carga tus pares de datos (X, Y) desde un archivo Excel."
                else
                    "Load your data pairs (X, Y) from an Excel file.",
                style = MaterialTheme.typography.bodyMedium,
                color = SlateBlue
            )
        }

        // ============================================
        // CONTENIDO SCROLLEABLE
        // ============================================
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // ---------- Tarjeta: A tomar en cuenta ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(Amber.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "⚠",
                                style = MaterialTheme.typography.labelSmall,
                                color = Amber,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "A tomar en cuenta"
                            else "Please note",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isSpanish)
                            "Para la importación masiva de datos mediante un archivo de Excel, organice la información en dos columnas sin encabezados, ni fila de títulos:"
                        else
                            "For bulk data import via an Excel file, organize the information in two columns without headers or title rows:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateBlue
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Columna A
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "A",
                                style = MonoNumberStyle,
                                color = CobaltBlue,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isSpanish) "Columna A" else "Column A",
                                style = MaterialTheme.typography.titleSmall,
                                color = GraphiteDark,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (isSpanish)
                                    "Valores numéricos correspondientes a la variable X."
                                else
                                    "Numeric values corresponding to variable X.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Columna B
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(EmeraldGreen.copy(alpha = 0.15f), RoundedCornerShape(6.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "B",
                                style = MonoNumberStyle,
                                color = EmeraldGreen,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isSpanish) "Columna B" else "Column B",
                                style = MaterialTheme.typography.titleSmall,
                                color = GraphiteDark,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (isSpanish)
                                    "Valores numéricos correspondientes a la variable Y."
                                else
                                    "Numeric values corresponding to variable Y.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    HorizontalDivider(color = Amber.copy(alpha = 0.3f))

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isSpanish)
                            "📌 Nota: Asegúrese de iniciar la secuencia de pares de datos desde la celda A1."
                        else
                            "📌 Note: Ensure you start the data pair sequence from cell A1.",
                        style = MaterialTheme.typography.bodySmall,
                        color = GraphiteDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // ---------- Tarjeta: Recomendación de carpeta ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📁", fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isSpanish) "Recomendación" else "Recommendation",
                            style = MaterialTheme.typography.titleSmall,
                            color = CobaltBlue,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (isSpanish)
                                "Se recomienda almacenar el archivo Excel en la carpeta 'Documentos' del dispositivo para facilitar el proceso."
                            else
                                "It is recommended to store the Excel file in the device's 'Documents' folder to facilitate the process.",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateBlue
                        )
                    }
                }
            }

            // ---------- Tarjeta: Ejemplo de estructura ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(VioletPurple.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isSpanish) "EJEMPLO" else "EXAMPLE",
                                style = MaterialTheme.typography.labelSmall,
                                color = VioletPurple,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Estructura esperada"
                            else "Expected structure",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tabla de ejemplo
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NeutralLightGray, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "A",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.labelMedium,
                            color = NeutralGray,
                            fontWeight = FontWeight.Black,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Text(
                            text = "B",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.labelMedium,
                            color = NeutralGray,
                            fontWeight = FontWeight.Black,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    listOf(
                        "2" to "0.846",
                        "4" to "0.573",
                        "6" to "0.401"
                    ).forEach { (x, y) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = x,
                                modifier = Modifier.weight(1f),
                                style = MonoNumberStyle,
                                color = GraphiteDark,
                                fontSize = 13.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Text(
                                text = y,
                                modifier = Modifier.weight(1f),
                                style = MonoNumberStyle,
                                color = GraphiteDark,
                                fontSize = 13.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                        HorizontalDivider(color = DividerSoft.copy(alpha = 0.5f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isSpanish)
                            "Cada fila representa un par (X, Y). Sin títulos, sin encabezados."
                        else
                            "Each row represents a pair (X, Y). No titles, no headers.",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeutralGray,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }

            // ---------- Botón para seleccionar archivo ----------
            Button(
                onClick = onFileSelected,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CobaltBlue,
                    contentColor = CardWhite
                )
            ) {
                Text(
                    text = "📂  " + if (isSpanish) "Seleccionar Archivo Excel"
                    else "Select Excel File",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
        }

        // ============================================
        // BARRA INFERIOR
        // ============================================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = if (isSpanish) "← Volver al Ingreso de Datos"
                    else "← Back to Data Entry",
                    color = SlateBlue,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}