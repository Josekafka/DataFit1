package com.fenix.datafit1.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================
// PALETA PROFESIONAL CIENTÍFICA - ANALYTICA
// ============================================

// Fondos neutros
val OffWhite           = Color(0xFFF9FAFB)   // Fondo principal de la app
val NeutralLightGray   = Color(0xFFF4F7F6)   // Fondo de tarjetas secundarias
val CardWhite          = Color(0xFFFFFFFF)   // Fondo de tarjetas Bento

// Grises y estructura
val NeutralGray        = Color(0xFFA0AEC0)   // Bordes, textos secundarios
val DividerSoft        = Color(0xFFE2E8F0)   // Líneas divisorias

// Tipografía
val SlateBlue          = Color(0xFF334155)   // Texto principal
val GraphiteDark       = Color(0xFF1E293B)   // Títulos

// Acentos de estado
val CobaltBlue         = Color(0xFF0047AB)   // Acción principal
val EmeraldGreen       = Color(0xFF10B981)   // Éxito / positivo
val Amber              = Color(0xFFF59E0B)   // Advertencia / variable crítica

// Acentos adicionales para gráficas
val VioletPurple       = Color(0xFF7C3AED)   // Curva LOG
val TurquoiseCyan      = Color(0xFF0891B2)   // Curva 1/X
val CoralRed           = Color(0xFFDC2626)   // Curva X²