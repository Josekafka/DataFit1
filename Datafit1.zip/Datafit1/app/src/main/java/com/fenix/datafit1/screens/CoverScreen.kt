package com.fenix.datafit1.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fenix.datafit1.R

@Composable
fun CoverScreen(
    isSpanish: Boolean,
    onLanguageChange: (Boolean) -> Unit,
    onEnter: () -> Unit
) {
    // Paleta de colores
    val verdeLimon       = Color(0xFFAEEA00)   // Verde limón para el botón activo
    val grisClaro        = Color(0xFFB0B0B0)   // Gris claro para el botón inactivo
    val textoNegro       = Color(0xFF1A1A1A)   // Casi negro

    Box(modifier = Modifier.fillMaxSize()) {

        // Imagen de fondo
        Image(
            painter = painterResource(id = R.drawable.portada),
            contentDescription = "Portada",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Contenido
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            // === SECCIÓN SUPERIOR: Botones de idioma ===
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Botón Español
                LanguageButton(
                    text = "Español",
                    isActive = isSpanish,
                    onClick = { onLanguageChange(true) },
                    modifier = Modifier.weight(1f)
                )

                // Botón English
                LanguageButton(
                    text = "English",
                    isActive = !isSpanish,
                    onClick = { onLanguageChange(false) },
                    modifier = Modifier.weight(1f)
                )
            }

            // === SECCIÓN INFERIOR: Botón de ingresar ===
            EnterProgramButton(
                text = if (isSpanish) "Ingresar al Programa"
                else "Enter Program",
                onClick = onEnter,
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(bottom = 24.dp)
            )
        }
    }
}

// ============================================
// BOTÓN DE IDIOMA CON GRADIENTE Y EFECTO 3D
// ============================================
@Composable
fun LanguageButton(
    text: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Colores según estado
    val colorTop = if (isActive) Color(0xFFC6F432) else Color(0xFFC8C8C8)     // Verde limón / Gris claro arriba
    val colorBottom = if (isActive) Color(0xFF9BC400) else Color(0xFF9E9E9E)  // Verde oscuro / Gris más oscuro abajo
    val shadowColor = if (isActive) Color(0xFF7A9E00) else Color(0xFF757575)  // Sombra 3D
    val textoNegro = Color(0xFF1A1A1A)

    // Contenedor con sombra 3D
    Box(
        modifier = modifier
            .height(58.dp)
            .padding(bottom = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        // Sombra 3D (bloque inferior)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    color = shadowColor,
                    shape = RoundedCornerShape(14.dp)
                )
        )

        // Botón principal con gradiente
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 4.dp)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(colorTop, colorBottom)
                    ),
                    shape = RoundedCornerShape(14.dp)
                )
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                color = textoNegro,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

// ============================================
// BOTÓN "INGRESAR AL PROGRAMA" CON GRADIENTE Y EFECTO 3D
// ============================================
@Composable
fun EnterProgramButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Colores verde limón (gradiente)
    val colorTop = Color(0xFFC6F432)       // Verde limón claro
    val colorBottom = Color(0xFF9BC400)    // Verde limón oscuro
    val shadowColor = Color(0xFF7A9E00)    // Sombra 3D
    val textoNegro = Color(0xFF1A1A1A)

    Box(
        modifier = modifier
            .height(64.dp)
            .padding(bottom = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        // Sombra 3D (bloque inferior)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    color = shadowColor,
                    shape = RoundedCornerShape(16.dp)
                )
        )

        // Botón principal con gradiente
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 6.dp)
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(colorTop, colorBottom)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.headlineSmall,
                color = textoNegro,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}