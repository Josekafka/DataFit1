package com.fenix.datafit1.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fenix.datafit1.ui.theme.*

@Composable
fun IntroScreen(
    isSpanish: Boolean,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        // ============================================
        // HEADER
        // ============================================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Text(
                text = "ANALYTICA SCIENTIFIC",
                style = MaterialTheme.typography.labelMedium,
                color = CobaltBlue,
                fontWeight = FontWeight.Black,   // ← Más negrita
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSpanish) "Ajuste de Curvas" else "Curve Fitting",
                style = MaterialTheme.typography.headlineSmall,
                color = GraphiteDark,
                fontWeight = FontWeight.Black    // ← Más negrita
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSpanish)
                    "Esta herramienta está diseñada para ayudarte a encontrar de forma rápida y exacta la relación matemática óptima entre dos variables."
                else
                    "This tool is designed to help you quickly and accurately find the optimal mathematical relationship between two variables.",
                style = MaterialTheme.typography.bodyMedium,
                color = SlateBlue
            )
        }

        // ============================================
        // CONTENIDO SCROLLEABLE
        // ============================================
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // ---------- Tarjeta 1: Beneficios ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isSpanish) "BENEFICIOS" else "BENEFITS",
                                style = MaterialTheme.typography.labelSmall,
                                color = CobaltBlue,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "¿Cómo te ayuda esta aplicación?"
                            else "How does this app help you?",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black     // ← Más negrita
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    BenefitRow(
                        icon = "⚙",
                        title = if (isSpanish) "Ajuste automático" else "Automatic fitting",
                        body = if (isSpanish)
                            "Modela tus datos frente a seis tipos de ecuaciones bajo la forma general Y = a + b · F(X), evaluando funciones lineales, logarítmicas, exponenciales, cuadráticas, entre otras."
                        else
                            "Fits your data against six types of equations under the general form Y = a + b · F(X), evaluating linear, logarithmic, exponential, quadratic functions, among others.",
                        color = CobaltBlue
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    BenefitRow(
                        icon = "✓",
                        title = if (isSpanish) "Evaluación de precisión" else "Precision evaluation",
                        body = if (isSpanish)
                            "Calcula automáticamente las constantes de regresión (a y b) y el coeficiente de correlación (r). Cuanto más cercano sea r a 1.0, mejor será la precisión del ajuste."
                        else
                            "Automatically calculates regression constants (a and b) and the correlation coefficient (r). The closer r is to 1.0, the better the fit accuracy.",
                        color = EmeraldGreen
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    BenefitRow(
                        icon = "▶",
                        title = if (isSpanish) "Fácil de usar" else "Easy to use",
                        body = if (isSpanish)
                            "Introduce tus pares de datos (X, Y) y la aplicación determinará al instante la ecuación que mejor describe el comportamiento de tus datos."
                        else
                            "Enter your data pairs (X, Y) and the app will instantly determine the equation that best describes your data's behavior.",
                        color = Amber
                    )
                }
            }

            // ---------- Tarjeta 2: Industria ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(EmeraldGreen.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isSpanish) "INDUSTRIA" else "INDUSTRY",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldGreen,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Aplicaciones en la Industria"
                            else "Industry Applications",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black     // ← Más negrita
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isSpanish)
                            "El ajuste de curvas bivariado (Y = a + b · F(X)) se utiliza en la investigación y la industria para modelar comportamientos, calibrar instrumentos y predecir tendencias a partir de datos experimentales."
                        else
                            "Bivariate curve fitting (Y = a + b · F(X)) is used in research and industry to model behaviors, calibrate instruments, and predict trends from experimental data.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateBlue,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    IndustryRow(
                        title = if (isSpanish) "Ingeniería Química y de Procesos" else "Chemical & Process Engineering",
                        body = if (isSpanish)
                            "Análisis de equilibrio de fases, cinética de reacciones químicas o viscosidad de fluidos según la temperatura."
                        else
                            "Phase equilibrium analysis, chemical reaction kinetics, or fluid viscosity by temperature.",
                        color = EmeraldGreen
                    )

                    IndustryRow(
                        title = if (isSpanish) "Control de Calidad y Calibración" else "Quality Control & Calibration",
                        body = if (isSpanish)
                            "Elaboración de curvas de calibración para sensores e instrumentos de medición."
                        else
                            "Calibration curves for sensors and measurement instruments.",
                        color = CobaltBlue
                    )

                    IndustryRow(
                        title = if (isSpanish) "Ingeniería Mecánica y de Materiales" else "Mechanical & Materials Engineering",
                        body = if (isSpanish)
                            "Ensayos de resistencia de materiales, fatiga de componentes o expansión térmica."
                        else
                            "Material strength tests, component fatigue, or thermal expansion.",
                        color = Amber
                    )

                    IndustryRow(
                        title = if (isSpanish) "Manufactura y Optimización" else "Manufacturing & Optimization",
                        body = if (isSpanish)
                            "Modelado del desgaste de herramientas o estimación del consumo de energía."
                        else
                            "Tool wear modeling or energy consumption estimation.",
                        color = CoralRed
                    )
                }
            }

            // ---------- Tarjeta 3: Investigación ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(VioletPurple.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isSpanish) "INVESTIGACIÓN" else "RESEARCH",
                                style = MaterialTheme.typography.labelSmall,
                                color = VioletPurple,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Aplicaciones en la Investigación"
                            else "Research Applications",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black     // ← Más negrita
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    IndustryRow(
                        title = if (isSpanish) "Ciencias de la Vida y Farmacología" else "Life Sciences & Pharmacology",
                        body = if (isSpanish)
                            "Análisis de dosis-respuesta y seguimiento de curvas de crecimiento microbiano o celular."
                        else
                            "Dose-response analysis and microbial or cell growth curves.",
                        color = VioletPurple
                    )

                    IndustryRow(
                        title = if (isSpanish) "Física y Química Experimental" else "Experimental Physics & Chemistry",
                        body = if (isSpanish)
                            "Validación de leyes empíricas como la ley de Beer-Lambert en espectrofotometría."
                        else
                            "Validation of empirical laws such as Beer-Lambert in spectrophotometry.",
                        color = TurquoiseCyan
                    )

                    IndustryRow(
                        title = if (isSpanish) "Ciencias Ambientales y Ecología" else "Environmental Sciences & Ecology",
                        body = if (isSpanish)
                            "Modelado de la tasa de degradación de contaminantes en agua o suelo."
                        else
                            "Modeling pollutant degradation rates in water or soil.",
                        color = EmeraldGreen
                    )

                    IndustryRow(
                        title = if (isSpanish) "Economía Aplicada y Econometría" else "Applied Economics & Econometrics",
                        body = if (isSpanish)
                            "Modelado de rendimientos decrecientes, elasticidad de la demanda o proyección de tendencias."
                        else
                            "Modeling diminishing returns, demand elasticity, or trend projection.",
                        color = Amber
                    )
                }
            }

            // ---------- Tarjeta 4: Modelos ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isSpanish) "MODELOS" else "MODELS",
                                style = MaterialTheme.typography.labelSmall,
                                color = CobaltBlue,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Modelos Evaluados" else "Evaluated Models",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black     // ← Más negrita
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    ModelChip("Y = a + b · X", CobaltBlue, isSpanish)
                    ModelChip("Y = a + b / X", TurquoiseCyan, isSpanish)
                    ModelChip("Y = a + b · LOG(X)", VioletPurple, isSpanish)
                    ModelChip("Y = a + b · SQR(X)", Amber, isSpanish)
                    ModelChip("Y = a + b · EXP(X)", EmeraldGreen, isSpanish)
                    ModelChip("Y = a + b · X²", CoralRed, isSpanish)
                }
            }

            // ---------- Tarjeta 5: Detalles ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(Amber.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "⚠",
                                style = MaterialTheme.typography.labelSmall,
                                color = Amber,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Detalles a tomar en cuenta"
                            else "Details to consider",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black     // ← Más negrita
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isSpanish)
                            "• Valores cero y negativos de X no se pueden usar con LOG.\n" +
                                    "• El valor cero de X no se puede usar con 1/X.\n" +
                                    "• Valores negativos no se pueden usar con √X ni exponentes fraccionarios.\n" +
                                    "• EXP(X) no se puede usar con X > 45 o X < -45."
                        else
                            "• Zero and negative X values cannot be used with LOG.\n" +
                                    "• Zero X cannot be used with 1/X.\n" +
                                    "• Negative values cannot be used with √X or fractional exponents.\n" +
                                    "• EXP(X) cannot be used with X > 45 or X < -45.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateBlue
                    )
                }
            }

            // ---------- Tarjeta 6: Excel ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(EmeraldGreen.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "EXCEL",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldGreen,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Importación desde Excel"
                            else "Excel Import",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black     // ← Más negrita
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isSpanish)
                            "Puedes cargar tus datos desde un archivo Excel. Organiza la información en dos columnas sin encabezados:\n" +
                                    "• Columna A: Valores de X\n" +
                                    "• Columna B: Valores de Y\n" +
                                    "Comienza desde la celda A1 y guarda el archivo en la carpeta 'Documentos'."
                        else
                            "You can load your data from an Excel file. Organize the information in two columns without headers:\n" +
                                    "• Column A: X values\n" +
                                    "• Column B: Y values\n" +
                                    "Start from cell A1 and save the file in the 'Documents' folder.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }

        // ============================================
        // BARRA INFERIOR
        // ============================================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(
                onClick = onBack,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = if (isSpanish) "Atrás" else "Back",
                    color = SlateBlue,
                    fontWeight = FontWeight.Bold
                )
            }
            Button(
                onClick = onNext,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CobaltBlue,
                    contentColor = CardWhite
                )
            ) {
                Text(
                    text = if (isSpanish) "Siguiente" else "Next",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ============================================
// COMPONENTES REUTILIZABLES
// ============================================

@Composable
fun BenefitRow(
    icon: String,
    title: String,
    body: String,
    color: Color
) {
    Row {
        Box(
            modifier = Modifier
                .size(28.dp)
                .background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, color = color, fontWeight = FontWeight.Black)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = GraphiteDark,
                fontWeight = FontWeight.Black    // ← Más negrita
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = SlateBlue
            )
        }
    }
}

@Composable
fun IndustryRow(
    title: String,
    body: String,
    color: Color
) {
    Row(
        modifier = Modifier.padding(vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .padding(top = 6.dp)
                .size(8.dp)
                .background(color, RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = GraphiteDark,
                fontWeight = FontWeight.Black    // ← Más negrita
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = SlateBlue
            )
        }
    }
}

@Composable
fun ModelChip(
    formula: String,
    color: Color,
    isSpanish: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, RoundedCornerShape(5.dp))
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = formula,
            style = MonoNumberStyle,
            color = SlateBlue,
            fontSize = 13.sp
        )
    }
}