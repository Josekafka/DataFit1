package com.fenix.datafit1

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.fenix.datafit1.screens.*
import com.fenix.datafit1.ui.theme.Datafit1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Datafit1Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AppNavigation(
                        modifier = Modifier.padding(innerPadding),
                        onExitApp = { finish() }
                    )
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    onExitApp: () -> Unit = {}
) {
    val navController = rememberNavController()
    val context = LocalContext.current

    // ============================================
    // ESTADO GLOBAL (persiste entre pantallas)
    // ============================================
    var isSpanish by remember { mutableStateOf(true) }
    var dataList by remember { mutableStateOf(listOf<DataPoint>()) }
    var modelResults by remember { mutableStateOf(listOf<ModelResult>()) }
    var pendingExcelData by remember { mutableStateOf<List<DataPoint>?>(null) }
    var predictions by remember { mutableStateOf(listOf<Prediction>()) }

    // Launcher para seleccionar archivo Excel
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val loadedData = CurveFittingLogic.readExcelFile(inputStream)
                    inputStream.close()

                    if (loadedData.isNotEmpty()) {
                        dataList = loadedData
                        modelResults = CurveFittingLogic.calculateAllModels(loadedData)
                        pendingExcelData = loadedData
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = "cover",
        modifier = modifier
    ) {
        composable("cover") {
            CoverScreen(
                isSpanish = isSpanish,
                onLanguageChange = { isSpanish = it },
                onEnter = { navController.navigate("intro") }
            )
        }

        composable("intro") {
            IntroScreen(
                isSpanish = isSpanish,
                onNext = { navController.navigate("data") },
                onBack = { navController.popBackStack() }
            )
        }

        composable("data") {
            DataEntryScreen(
                isSpanish = isSpanish,
                dataList = dataList,
                onDataListChange = { newList: List<DataPoint> ->
                    dataList = newList
                    modelResults = CurveFittingLogic.calculateAllModels(newList)
                },
                initialData = pendingExcelData,
                onDataConsumed = { pendingExcelData = null },
                predictions = predictions,
                onNext = { navController.navigate("results") },
                onBack = { navController.popBackStack() },
                onOpenExcel = { navController.navigate("excel") }
            )
        }

        composable("excel") {
            ExcelImportScreen(
                isSpanish = isSpanish,
                onBack = { navController.popBackStack() },
                onFileSelected = {
                    filePickerLauncher.launch("*/*")
                    navController.popBackStack()
                }
            )
        }

        composable("results") {
            ResultsScreen(
                isSpanish = isSpanish,
                dataPoints = dataList,
                results = modelResults,
                predictions = predictions,
                onPredictionsChange = { predictions = it },
                onNext = { navController.navigate("charts") },
                onBack = { navController.popBackStack() }
            )
        }

        composable("charts") {
            ChartsScreen(
                isSpanish = isSpanish,
                dataPoints = dataList,
                results = modelResults,
                onFinish = { onExitApp() },
                onBack = { navController.popBackStack() }
            )
        }
    }
}