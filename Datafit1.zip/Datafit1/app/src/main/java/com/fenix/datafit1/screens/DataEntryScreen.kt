package com.fenix.datafit1.screens

import com.fenix.datafit1.Prediction
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fenix.datafit1.CurveFittingLogic
import com.fenix.datafit1.DataPoint
import com.fenix.datafit1.SampleData
import com.fenix.datafit1.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun DataEntryScreen(
    isSpanish: Boolean,
    dataList: List<DataPoint>,
    onDataListChange: (List<DataPoint>) -> Unit,
    initialData: List<DataPoint>? = null,
    onDataConsumed: () -> Unit = {},
    predictions: List<Prediction> = emptyList(),
    onNext: () -> Unit,
    onBack: () -> Unit,
    onOpenExcel: () -> Unit
) {
    var inputX by remember { mutableStateOf("") }
    var inputY by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Detectar si llegaron datos desde Excel
    LaunchedEffect(initialData) {
        if (initialData != null && initialData.isNotEmpty()) {
            onDataListChange(initialData)
            errorMsg = ""
            onDataConsumed()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(OffWhite)
        ) {

            // ============================================
            // HEADER
            // ============================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardWhite)
                    .padding(horizontal = 24.dp, vertical = 20.dp)
            ) {
                Text(
                    text = "ANALYTICA SCIENTIFIC",
                    style = MaterialTheme.typography.labelMedium,
                    color = CobaltBlue,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isSpanish) "Ingreso de Datos" else "Data Entry",
                    style = MaterialTheme.typography.headlineSmall,
                    color = GraphiteDark,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isSpanish)
                        "Introduce tus pares de datos (X, Y) uno por uno, o cárgalos desde un archivo Excel."
                    else
                        "Enter your data pairs (X, Y) one by one, or load them from an Excel file.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateBlue
                )
            }

            // ============================================
            // CONTENIDO SCROLLEABLE
            // ============================================
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                // ---------- Tarjeta 1: Entrada Manual ----------
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = if (isSpanish) "ENTRADA" else "INPUT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CobaltBlue,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSpanish) "Entrada Manual" else "Manual Entry",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = inputX,
                                    onValueChange = { inputX = it },
                                    label = { Text("X") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = inputY,
                                    onValueChange = { inputY = it },
                                    label = { Text("Y") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val x = inputX.replace(',', '.').toDoubleOrNull()
                                        val y = inputY.replace(',', '.').toDoubleOrNull()
                                        if (x != null && y != null) {
                                            onDataListChange(dataList + DataPoint(x, y))
                                            inputX = ""
                                            inputY = ""
                                            errorMsg = ""
                                        } else {
                                            errorMsg = if (isSpanish)
                                                "Ingrese valores numéricos válidos."
                                            else
                                                "Enter valid numeric values."
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldGreen,
                                        contentColor = CardWhite
                                    )
                                ) {
                                    Text(
                                        text = if (isSpanish) "+ Agregar Par" else "+ Add Pair",
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = onOpenExcel,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "📂 Excel",
                                        color = CobaltBlue,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            if (errorMsg.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = errorMsg,
                                    color = CoralRed,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // ---------- Tarjeta 2: Ejemplo Rápido ----------
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(VioletPurple.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = if (isSpanish) "EJEMPLO" else "EXAMPLE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VioletPurple,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSpanish) "Ejemplo Rápido" else "Quick Example",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (isSpanish)
                                    "Carga datos de prueba para validar los resultados."
                                else
                                    "Load test data to validate the results.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateBlue
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    onDataListChange(SampleData.acidoNitrico)
                                    errorMsg = ""
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = VioletPurple,
                                    contentColor = CardWhite
                                )
                            ) {
                                Text(
                                    text = if (isSpanish) "🧪 Cargar Ejemplo: Ácido Nítrico"
                                    else "🧪 Load Example: Nitric Acid",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // ---------- Tarjeta 3: Guardar Análisis ----------
                if (dataList.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardWhite),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(Amber.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = if (isSpanish) "EXPORTAR" else "EXPORT",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Amber,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isSpanish) "Guardar Análisis"
                                        else "Save Analysis",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = GraphiteDark,
                                        fontWeight = FontWeight.Black
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = if (isSpanish)
                                        "Exporta los datos, el modelo ganador y las predicciones a un archivo CSV que puedes abrir en Excel."
                                    else
                                        "Export the data, the winning model and the predictions to a CSV file you can open in Excel.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateBlue
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        val modelResults = CurveFittingLogic.calculateAllModels(dataList)
                                        val fileName = CurveFittingLogic.saveAnalysisToCsv(
                                            context,
                                            dataList,
                                            modelResults,
                                            predictions
                                        )
                                        scope.launch {
                                            if (fileName != null) {
                                                snackbarHostState.showSnackbar(
                                                    if (isSpanish)
                                                        "✅ Guardado en Downloads/$fileName"
                                                    else
                                                        "✅ Saved to Downloads/$fileName"
                                                )
                                            } else {
                                                snackbarHostState.showSnackbar(
                                                    if (isSpanish)
                                                        "❌ Error al guardar el archivo"
                                                    else
                                                        "❌ Error saving the file"
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Amber,
                                        contentColor = CardWhite
                                    )
                                ) {
                                    Text(
                                        text = if (isSpanish) "💾 Guardar en Downloads"
                                        else "💾 Save to Downloads",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // ---------- Tarjeta 4: Detalles a considerar ----------
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(Amber.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "⚠",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Amber,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSpanish) "Detalles a considerar"
                                    else "Details to consider",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isSpanish)
                                    "• Valores cero y negativos de X no se pueden usar con LOG.\n" +
                                            "• El valor cero de X no se puede usar con 1/X.\n" +
                                            "• Valores negativos no se pueden usar con √X ni exponentes fraccionarios.\n" +
                                            "• EXP(X) no se puede usar con X > 45 o X < -45."
                                else
                                    "• Zero and negative X values cannot be used with LOG.\n" +
                                            "• Zero X cannot be used with 1/X.\n" +
                                            "• Negative values cannot be used with √X or fractional exponents.\n" +
                                            "• EXP(X) cannot be used with X > 45 or X < -45.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateBlue
                            )
                        }
                    }
                }

                // ---------- Encabezado de la Tabla ----------
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSpanish) "Datos Ingresados" else "Entered Data",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black
                        )
                        Box(
                            modifier = Modifier
                                .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${dataList.size} ${if (isSpanish) "pares" else "pairs"}",
                                style = MaterialTheme.typography.labelMedium,
                                color = CobaltBlue,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // ---------- Lista de registros ----------
                if (dataList.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardWhite),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (isSpanish)
                                    "Aún no has agregado datos. Ingresa tu primer par (X, Y) arriba o carga el ejemplo."
                                else
                                    "You haven't added data yet. Enter your first pair (X, Y) above or load the example.",
                                modifier = Modifier.padding(24.dp),
                                style = MaterialTheme.typography.bodyMedium,
                                color = NeutralGray,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                } else {
                    itemsIndexed(dataList) { index, point ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardWhite),
                            shape = RoundedCornerShape(10.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(CobaltBlue.copy(alpha = 0.10f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        style = MonoNumberStyle,
                                        color = CobaltBlue,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "X = ${point.x}",
                                        style = MonoNumberStyle,
                                        color = GraphiteDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Y = ${point.y}",
                                        style = MonoNumberStyle,
                                        color = SlateBlue,
                                        fontSize = 13.sp
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        onDataListChange(
                                            dataList.toMutableList().apply { removeAt(index) }
                                        )
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = CoralRed
                                    )
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(8.dp)) }
            }

            // ============================================
            // BARRA INFERIOR
            // ============================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardWhite)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isSpanish) "Atrás" else "Back",
                        color = SlateBlue,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onNext,
                    enabled = dataList.size >= 2,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CobaltBlue,
                        contentColor = CardWhite,
                        disabledContainerColor = NeutralGray,
                        disabledContentColor = CardWhite
                    )
                ) {
                    Text(
                        text = if (isSpanish) "Calcular y Siguiente"
                        else "Calculate & Next",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Notificaciones (Snackbar) flotantes
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}