package com.fenix.datafit1

// ============================================
// DATOS DE EJEMPLO PRECONFIGURADOS
// ============================================

object SampleData {

    // Ejemplo: Análisis de Ácido Nítrico
    // Fuente: Ejemplo bibliográfico clásico de ajuste de curvas
    // Modelo esperado: LOG(X) con R ≈ 0.9977
    val acidoNitrico: List<DataPoint> = listOf(
        DataPoint(2.0, 0.846),
        DataPoint(4.0, 0.573),
        DataPoint(6.0, 0.401),
        DataPoint(8.0, 0.280),
        DataPoint(10.0, 0.209),
        DataPoint(12.0, 0.153),
        DataPoint(14.0, 0.111),
        DataPoint(16.0, 0.078)
    )

    // Aquí podemos agregar más ejemplos en el futuro:
    // val leyDeBoyle: List<DataPoint> = listOf(...)
    // val leyesDeKepler: List<DataPoint> = listOf(...)
    // val crecimientoMicrobiano: List<DataPoint> = listOf(...)
    // etc.
}