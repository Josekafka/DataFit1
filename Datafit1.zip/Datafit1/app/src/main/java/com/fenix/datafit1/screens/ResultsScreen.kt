package com.fenix.datafit1.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fenix.datafit1.CurveFittingLogic
import com.fenix.datafit1.DataPoint
import com.fenix.datafit1.ModelResult
import com.fenix.datafit1.Prediction
import com.fenix.datafit1.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ResultsScreen(
    isSpanish: Boolean,
    dataPoints: List<DataPoint>,
    results: List<ModelResult>,
    predictions: List<Prediction>,
    onPredictionsChange: (List<Prediction>) -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    var inputPredictX by remember { mutableStateOf("") }
    var outputPredictY by remember { mutableStateOf("") }
    var inputPredictY by remember { mutableStateOf("") }
    var outputPredictX by remember { mutableStateOf("") }

    val winner = results.firstOrNull { it.isValid }
    val rSquared = winner?.let { (it.r * it.r * 100) } ?: 0.0
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(OffWhite)
        ) {

            // ============================================
            // HEADER
            // ============================================
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardWhite)
                    .padding(horizontal = 24.dp, vertical = 20.dp)
            ) {
                Text(
                    text = "ANALYTICA SCIENTIFIC",
                    style = MaterialTheme.typography.labelMedium,
                    color = CobaltBlue,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isSpanish) "Resultados y Predicción"
                    else "Results & Prediction",
                    style = MaterialTheme.typography.headlineSmall,
                    color = GraphiteDark,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isSpanish)
                        "Análisis de los 6 modelos evaluados con tus datos."
                    else
                        "Analysis of the 6 models evaluated with your data.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateBlue
                )
            }

            // ============================================
            // CONTENIDO SCROLLEABLE
            // ============================================
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                // ---------- Tarjeta: Modelo Ganador ----------
                if (winner != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(EmeraldGreen, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = if (isSpanish) "★ GANADOR" else "★ WINNER",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CardWhite,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = winner.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = GraphiteDark,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = winner.formula,
                                    style = MonoNumberStyle,
                                    color = GraphiteDark,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    MetricMini("R", String.format("%.4f", winner.r), EmeraldGreen)
                                    MetricMini("R² (%)", String.format("%.2f", rSquared), CobaltBlue)
                                    MetricMini(if (isSpanish) "Error" else "Error", String.format("%.4f", winner.error), Amber)
                                }
                            }
                        }
                    }
                }

                // ---------- Tarjeta: Comparativa de Modelos ----------
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = if (isSpanish) "COMPARATIVA" else "COMPARISON",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CobaltBlue,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSpanish) "Modelos Evaluados" else "Evaluated Models",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(if (isSpanish) "MODELO" else "MODEL", modifier = Modifier.weight(1.3f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                Text("A", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                Text("B", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                Text("R", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                            }
                            HorizontalDivider(color = DividerSoft)
                            results.forEach { model ->
                                if (model.isValid) {
                                    val isWinner = (model.name == winner?.name)
                                    ModelTableRow(model = model, isWinner = isWinner)
                                }
                            }
                        }
                    }
                }

                // ---------- Tarjeta: Tabla de Residuos ----------
                if (winner != null && dataPoints.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardWhite),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(Amber.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = if (isSpanish) "RESIDUOS" else "RESIDUALS",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Amber,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isSpanish) "Tabla de Residuos" else "Residuals Table",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = GraphiteDark,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isSpanish) "Modelo: ${winner.name}" else "Model: ${winner.name}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateBlue,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("#", modifier = Modifier.width(30.dp), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                    Text("X", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                    Text("Y obs.", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                    Text("Y calc.", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                    Text("Resid.", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
                                }
                                HorizontalDivider(color = DividerSoft)
                                dataPoints.forEachIndexed { index, point ->
                                    val yCalc = CurveFittingLogic.predictY(winner, point.x)
                                    val residual = point.y - yCalc
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${index + 1}", modifier = Modifier.width(30.dp), style = MonoNumberStyle, color = NeutralGray, fontSize = 12.sp)
                                        Text(String.format("%.2f", point.x), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = GraphiteDark, fontSize = 12.sp)
                                        Text(String.format("%.4f", point.y), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = GraphiteDark, fontSize = 12.sp)
                                        Text(String.format("%.4f", yCalc), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = CobaltBlue, fontSize = 12.sp)
                                        Text(String.format("%+.4f", residual), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = if (kotlin.math.abs(residual) < 0.01) EmeraldGreen else Amber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // ---------- Tarjeta: Opción Predictiva ----------
                if (winner != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardWhite),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(VioletPurple.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = if (isSpanish) "PREDICCIÓN" else "PREDICTION",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = VioletPurple,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isSpanish) "Opción Predictiva" else "Predictive Option",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = GraphiteDark,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isSpanish) "Usando el modelo ganador: ${winner.formula}" else "Using winner model: ${winner.formula}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateBlue,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                                Spacer(modifier = Modifier.height(16.dp))

                                // Predecir Y desde X
                                Text(
                                    text = if (isSpanish) "Calcular Y desde X:" else "Calculate Y from X:",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = inputPredictX,
                                        onValueChange = {
                                            inputPredictX = it
                                            val x = it.replace(',', '.').toDoubleOrNull()
                                            outputPredictY = if (x != null) {
                                                val y = CurveFittingLogic.predictY(winner, x)
                                                if (y.isNaN()) "Error"
                                                else {
                                                    onPredictionsChange(predictions + Prediction("Directa (X -> Y)", x, y))
                                                    String.format("%.4f", y)
                                                }
                                            } else ""
                                        },
                                        label = { Text("X") },
                                        modifier = Modifier.weight(1f),
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    Text("→", style = MaterialTheme.typography.titleLarge, color = VioletPurple)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(VioletPurple.copy(alpha = 0.10f), RoundedCornerShape(10.dp))
                                            .padding(vertical = 16.dp, horizontal = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(outputPredictY.ifEmpty { "—" }, style = MonoNumberStyle, color = VioletPurple, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(16.dp))

                                // Predecir X desde Y
                                Text(
                                    text = if (isSpanish) "Calcular X desde Y (inversa):" else "Calculate X from Y (inverse):",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = inputPredictY,
                                        onValueChange = {
                                            inputPredictY = it
                                            val y = it.replace(',', '.').toDoubleOrNull()
                                            outputPredictX = if (y != null) {
                                                val x = CurveFittingLogic.predictX(winner, y)
                                                if (x.isNaN()) "Error"
                                                else {
                                                    onPredictionsChange(predictions + Prediction("Inversa (Y -> X)", y, x))
                                                    String.format("%.4f", x)
                                                }
                                            } else ""
                                        },
                                        label = { Text("Y") },
                                        modifier = Modifier.weight(1f),
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    Text("→", style = MaterialTheme.typography.titleLarge, color = TurquoiseCyan)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(TurquoiseCyan.copy(alpha = 0.10f), RoundedCornerShape(10.dp))
                                            .padding(vertical = 16.dp, horizontal = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(outputPredictX.ifEmpty { "—" }, style = MonoNumberStyle, color = TurquoiseCyan, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // ---------- Tarjeta: Guardar Análisis ----------
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(Amber.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = if (isSpanish) "EXPORTAR" else "EXPORT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Amber,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSpanish) "Guardar Análisis" else "Save Analysis",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isSpanish)
                                    "Exporta los datos, el modelo ganador, las predicciones y la comparativa a un archivo CSV."
                                else
                                    "Export the data, the winning model, the predictions and the comparison to a CSV file.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateBlue
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    val fileName = CurveFittingLogic.saveAnalysisToCsv(context, dataPoints, results, predictions)
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (fileName != null)
                                                if (isSpanish) "✅ Guardado en Downloads/$fileName" else "✅ Saved to Downloads/$fileName"
                                            else
                                                if (isSpanish) "❌ Error al guardar el archivo" else "❌ Error saving the file"
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = CardWhite)
                            ) {
                                Text(
                                    text = if (isSpanish) "💾 Guardar en Downloads" else "💾 Save to Downloads",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // ---------- Tarjeta: Glosario de Símbolos ----------
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NeutralLightGray),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(NeutralGray.copy(alpha = 0.20f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text("ℹ", style = MaterialTheme.typography.labelSmall, color = SlateBlue, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isSpanish) "Glosario de Símbolos" else "Symbols Glossary",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = GraphiteDark,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            GlossaryRow("A", CobaltBlue, if (isSpanish) "Valor de Y cuando F(X) = 0. Punto donde la recta cruza el eje Y." else "Value of Y when F(X) = 0. Point where the line crosses the Y axis.")
                            Spacer(modifier = Modifier.height(10.dp))
                            GlossaryRow("B", EmeraldGreen, if (isSpanish) "Inclinación de la recta. Cuánto cambia Y por cada unidad de F(X)." else "Slope of the line. How much Y changes per unit of F(X).")
                            Spacer(modifier = Modifier.height(10.dp))
                            GlossaryRow("R", VioletPurple, if (isSpanish) "Coeficiente de correlación. Mide qué tan bien se ajusta el modelo." else "Correlation coefficient. Measures how well the model fits.")
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(8.dp)) }
            }

            // ============================================
            // BARRA INFERIOR
            // ============================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardWhite)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isSpanish) "Atrás" else "Back",
                        color = SlateBlue,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onNext,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CobaltBlue,
                        contentColor = CardWhite
                    )
                ) {
                    Text(
                        text = if (isSpanish) "Ver Gráficas" else "View Charts",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Notificaciones (Snackbar) flotantes - FUERA del Column, DENTRO del Box
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ============================================
// COMPONENTES REUTILIZABLES
// ============================================

@Composable
fun MetricMini(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = NeutralGray, fontWeight = FontWeight.Black)
        Text(value, style = MonoNumberStyle, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun ModelTableRow(model: ModelResult, isWinner: Boolean) {
    val color = when (model.name) {
        "Lineal" -> CobaltBlue
        "1/X"    -> TurquoiseCyan
        "LOG(X)" -> VioletPurple
        "SQR(X)" -> Amber
        "EXP(X)" -> EmeraldGreen
        "X^2"    -> CoralRed
        else     -> NeutralGray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isWinner) EmeraldGreen.copy(alpha = 0.08f) else Color.Transparent)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1.3f), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).background(color, RoundedCornerShape(4.dp)))
            Spacer(modifier = Modifier.width(6.dp))
            Text(model.name, style = MaterialTheme.typography.bodySmall, color = GraphiteDark, fontWeight = if (isWinner) FontWeight.Black else FontWeight.Medium)
        }
        Text(String.format("%.4f", model.a), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = SlateBlue, fontSize = 12.sp)
        Text(String.format("%.4f", model.b), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = SlateBlue, fontSize = 12.sp)
        Text(String.format("%.4f", model.r), modifier = Modifier.weight(1f), style = MonoNumberStyle, color = if (isWinner) EmeraldGreen else SlateBlue, fontWeight = if (isWinner) FontWeight.Bold else FontWeight.Medium, fontSize = 12.sp)
    }
    HorizontalDivider(color = DividerSoft.copy(alpha = 0.5f))
}

@Composable
fun GlossaryRow(symbol: String, color: Color, description: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier.size(32.dp).background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(symbol, style = MonoNumberStyle, color = color, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(description, style = MaterialTheme.typography.bodySmall, color = SlateBlue, modifier = Modifier.weight(1f))
    }
}