package com.fenix.datafit1.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fenix.datafit1.CurveFittingLogic
import com.fenix.datafit1.DataPoint
import com.fenix.datafit1.ModelResult
import com.fenix.datafit1.ui.theme.*
import kotlin.math.ceil
import kotlin.math.floor

@Composable
fun ChartsScreen(
    isSpanish: Boolean,
    dataPoints: List<DataPoint>,
    results: List<ModelResult>,
    onFinish: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        // ============================================
        // HEADER
        // ============================================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 24.dp, vertical = 20.dp)
        ) {
            Text(
                text = "ANALYTICA SCIENTIFIC",
                style = MaterialTheme.typography.labelMedium,
                color = CobaltBlue,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSpanish) "Gráficas Multimodelo"
                else "Multi-Model Charts",
                style = MaterialTheme.typography.headlineSmall,
                color = GraphiteDark,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isSpanish)
                    "Comparación visual de los 6 modelos evaluados."
                else
                    "Visual comparison of the 6 evaluated models.",
                style = MaterialTheme.typography.bodyMedium,
                color = SlateBlue
            )
        }

        // ============================================
        // CONTENIDO
        // ============================================
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // ---------- Tarjeta del Gráfico ----------
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(CobaltBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isSpanish) "GRÁFICO" else "CHART",
                                style = MaterialTheme.typography.labelSmall,
                                color = CobaltBlue,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "Dispersión y Curvas"
                            else "Scatter & Curves",
                            style = MaterialTheme.typography.titleMedium,
                            color = GraphiteDark,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Aquí va el Canvas del gráfico
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        DataChart(
                            dataPoints = dataPoints,
                            results = results
                        )
                    }
                }
            }

            // ---------- Tarjeta de Leyenda ----------
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSpanish) "Leyenda" else "Legend",
                        style = MaterialTheme.typography.titleMedium,
                        color = GraphiteDark,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendChip("Lineal", CobaltBlue)
                        LegendChip("EXP(X)", EmeraldGreen)
                        LegendChip("X²", CoralRed)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendChip("LOG(X)", VioletPurple)
                        LegendChip("SQR(X)", Amber)
                        LegendChip("1/X", TurquoiseCyan)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = DividerSoft)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(CoralRed, RoundedCornerShape(7.dp))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSpanish) "Puntos observados (datos reales)"
                            else "Observed points (real data)",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateBlue,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // ============================================
        // BARRA INFERIOR
        // ============================================
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onBack,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = if (isSpanish) "Atrás" else "Back",
                    color = SlateBlue,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onFinish,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldGreen,
                    contentColor = CardWhite
                )
            ) {
                Text(
                    text = if (isSpanish) "Terminar y Salir" else "Finish & Exit",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ============================================
// GRÁFICO PRINCIPAL
// ============================================
@Composable
fun DataChart(
    dataPoints: List<DataPoint>,
    results: List<ModelResult>
) {
    val textMeasurer = rememberTextMeasurer()

    Canvas(modifier = Modifier.fillMaxSize()) {
        if (dataPoints.isEmpty()) return@Canvas

        // Márgenes para ejes y etiquetas
        val leftMargin = 55f
        val bottomMargin = 40f
        val topMargin = 15f
        val rightMargin = 15f

        val chartWidth = size.width - leftMargin - rightMargin
        val chartHeight = size.height - bottomMargin - topMargin

        // Calcular rangos de X e Y
        val minX = dataPoints.minOf { it.x }
        val maxX = dataPoints.maxOf { it.x }
        val minY = dataPoints.minOf { it.y }
        val maxY = dataPoints.maxOf { it.y }

        // Redondear los rangos para que quepan en "números bonitos"
        val rangeX = if (maxX - minX == 0.0) 1.0 else maxX - minX
        val rangeY = if (maxY - minY == 0.0) 1.0 else maxY - minY

        val paddedMinX = minX
        val paddedMaxX = maxX
        val paddedMinY = floor(minY * 10) / 10.0
        val paddedMaxY = ceil(maxY * 10) / 10.0
        val paddedRangeY = paddedMaxY - paddedMinY

        // Función para convertir X del dato a coordenada de pantalla
        fun toScreenX(x: Double): Float {
            return leftMargin + ((x - paddedMinX) / rangeX * chartWidth).toFloat()
        }

        // Función para convertir Y del dato a coordenada de pantalla
        fun toScreenY(y: Double): Float {
            return topMargin + chartHeight - ((y - paddedMinY) / paddedRangeY * chartHeight).toFloat()
        }

        // ============================================
        // 1. Dibujar cuadrícula y etiquetas
        // ============================================
        val gridColor = DividerSoft
        val labelStyle = TextStyle(
            color = NeutralGray,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )

        // Líneas verticales (eje X)
        val xTicks = 5
        for (i in 0..xTicks) {
            val value = paddedMinX + (rangeX * i / xTicks)
            val screenX = toScreenX(value)

            // Línea vertical
            drawLine(
                color = gridColor,
                start = Offset(screenX, topMargin),
                end = Offset(screenX, topMargin + chartHeight),
                strokeWidth = 1f
            )

            // Etiqueta en el eje X
            val label = if (rangeX < 5) String.format("%.1f", value) else String.format("%.0f", value)
            val textLayout = textMeasurer.measure(label, labelStyle)
            drawText(
                textLayoutResult = textLayout,
                topLeft = Offset(
                    screenX - textLayout.size.width / 2f,
                    topMargin + chartHeight + 8f
                )
            )
        }

        // Líneas horizontales (eje Y)
        val yTicks = 5
        for (i in 0..yTicks) {
            val value = paddedMinY + (paddedRangeY * i / yTicks)
            val screenY = toScreenY(value)

            // Línea horizontal
            drawLine(
                color = gridColor,
                start = Offset(leftMargin, screenY),
                end = Offset(leftMargin + chartWidth, screenY),
                strokeWidth = 1f
            )

            // Etiqueta en el eje Y
            val label = String.format("%.2f", value)
            val textLayout = textMeasurer.measure(label, labelStyle)
            drawText(
                textLayoutResult = textLayout,
                topLeft = Offset(
                    leftMargin - textLayout.size.width - 6f,
                    screenY - textLayout.size.height / 2f
                )
            )
        }

        // Ejes principales
        drawLine(
            color = NeutralGray,
            start = Offset(leftMargin, topMargin),
            end = Offset(leftMargin, topMargin + chartHeight),
            strokeWidth = 2f
        )
        drawLine(
            color = NeutralGray,
            start = Offset(leftMargin, topMargin + chartHeight),
            end = Offset(leftMargin + chartWidth, topMargin + chartHeight),
            strokeWidth = 2f
        )

        // ============================================
        // 2. Dibujar las curvas de los modelos
        // ============================================
        results.filter { it.isValid }.forEach { model ->
            val color = when (model.name) {
                "Lineal" -> CobaltBlue
                "EXP(X)" -> EmeraldGreen
                "X^2"    -> CoralRed
                "LOG(X)" -> VioletPurple
                "SQR(X)" -> Amber
                "1/X"    -> TurquoiseCyan
                else     -> NeutralGray
            }

            val path = Path()
            var first = true
            val steps = 150

            for (i in 0..steps) {
                val xVal = paddedMinX + (rangeX * i / steps)
                val yVal = CurveFittingLogic.predictY(model, xVal)

                // Solo dibujar si el valor es válido y no está muy fuera del rango
                if (!yVal.isNaN() && yVal >= paddedMinY - paddedRangeY * 0.5
                    && yVal <= paddedMaxY + paddedRangeY * 0.5) {

                    val screenX = toScreenX(xVal)
                    val screenY = toScreenY(yVal)

                    if (first) {
                        path.moveTo(screenX, screenY)
                        first = false
                    } else {
                        path.lineTo(screenX, screenY)
                    }
                }
            }

            drawPath(
                path = path,
                color = color,
                style = Stroke(width = 3f)
            )
        }

        // ============================================
        // 3. Dibujar los puntos observados (rojo con halo blanco)
        // ============================================
        dataPoints.forEach { p ->
            val screenX = toScreenX(p.x)
            val screenY = toScreenY(p.y)

            // Halo blanco
            drawCircle(
                color = CardWhite,
                radius = 10f,
                center = Offset(screenX, screenY)
            )

            // Punto rojo
            drawCircle(
                color = CoralRed,
                radius = 6f,
                center = Offset(screenX, screenY)
            )
        }
    }
}

// ============================================
// COMPONENTE DE LEYENDA
// ============================================
@Composable
fun LegendChip(name: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(14.dp)
                .background(color, RoundedCornerShape(7.dp))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodySmall,
            color = SlateBlue,
            fontWeight = FontWeight.Medium
        )
    }
}