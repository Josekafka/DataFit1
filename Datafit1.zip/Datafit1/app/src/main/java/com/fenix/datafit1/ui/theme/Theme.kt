package com.fenix.datafit1.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ============================================
// TEMA DE LA APLICACIÓN
// Siempre modo claro (diseño científico)
// ============================================

private val LightColorScheme = lightColorScheme(
    primary          = CobaltBlue,
    onPrimary        = CardWhite,
    secondary        = EmeraldGreen,
    onSecondary      = CardWhite,
    tertiary         = Amber,
    onTertiary       = CardWhite,

    background       = OffWhite,
    onBackground     = GraphiteDark,
    surface          = CardWhite,
    onSurface        = SlateBlue,
    surfaceVariant   = NeutralLightGray,
    onSurfaceVariant = SlateBlue,

    outline          = NeutralGray,
    error            = CoralRed
)

private val DarkColorScheme = darkColorScheme(
    primary          = CobaltBlue,
    secondary        = EmeraldGreen,
    tertiary         = Amber,
    background       = GraphiteDark,
    surface          = Color(0xFF334155),
    onSurface        = CardWhite
)

@Composable
fun Datafit1Theme(
    darkTheme: Boolean = false, // Forzamos modo claro
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}