package com.fenix.datafit1

import kotlin.math.*

data class DataPoint(val x: Double, val y: Double)

data class ModelResult(
    val name: String,
    val a: Double,
    val b: Double,
    val r: Double,
    val error: Double,
    val isValid: Boolean,
    val formula: String
)
data class Prediction(
    val tipo: String,      // "Directa (X → Y)" o "Inversa (Y → X)"
    val entrada: Double,   // El valor ingresado (X o Y)
    val salida: Double     // El valor calculado (Y o X)
)
object CurveFittingLogic {

    fun calculateAllModels(data: List<DataPoint>): List<ModelResult> {
        val n = data.size
        if (n < 2) return emptyList()

        val results = mutableListOf<ModelResult>()

        results.add(calculateModel(data, "Lineal") { it.x })

        if (data.none { it.x == 0.0 }) {
            results.add(calculateModel(data, "1/X") { 1.0 / it.x })
        } else {
            results.add(ModelResult("1/X", 0.0, 0.0, 0.0, 0.0, false, ""))
        }

        if (data.none { it.x <= 0.0 }) {
            results.add(calculateModel(data, "LOG(X)") { ln(it.x) })
        } else {
            results.add(ModelResult("LOG(X)", 0.0, 0.0, 0.0, 0.0, false, ""))
        }

        if (data.none { it.x < 0.0 }) {
            results.add(calculateModel(data, "SQR(X)") { sqrt(it.x) })
        } else {
            results.add(ModelResult("SQR(X)", 0.0, 0.0, 0.0, 0.0, false, ""))
        }

        if (data.none { it.x > 45 || it.x < -45 }) {
            results.add(calculateModel(data, "EXP(X)") { exp(it.x) })
        } else {
            results.add(ModelResult("EXP(X)", 0.0, 0.0, 0.0, 0.0, false, ""))
        }

        results.add(calculateModel(data, "X^2") { it.x * it.x })

        return results.sortedByDescending { it.r }
    }

    private fun calculateModel(
        data: List<DataPoint>,
        name: String,
        f: (DataPoint) -> Double
    ): ModelResult {
        val n = data.size.toDouble()

        var sumF = 0.0
        var sumSqF = 0.0
        var sumY = 0.0
        var sumYF = 0.0
        var sumYSq = 0.0

        try {
            for (p in data) {
                val fx = f(p)
                sumF += fx
                sumSqF += fx * fx
                sumY += p.y
                sumYF += p.y * fx
                sumYSq += p.y * p.y
            }

            val xDenom = sumSqF - (sumF * sumF) / n
            val yDenom = sumYF - (sumF * sumY) / n

            if (xDenom == 0.0) {
                return ModelResult(name, 0.0, 0.0, 0.0, 0.0, false, "")
            }

            val b = yDenom / xDenom
            val a = (sumY / n) - b * (sumF / n)

            val py = sumYSq - (sumY * sumY) / n
            var r = if (py == 0.0) 0.0 else (b * yDenom) / py
            r = if (r < 0) -sqrt(-r) else sqrt(r)

            var sumResidualsSq = 0.0
            for (p in data) {
                val yCalc = a + b * f(p)
                sumResidualsSq += (p.y - yCalc).pow(2)
            }
            val stdError = if (n > 2) sqrt(sumResidualsSq / (n - 2)) else 0.0

            val formula = generateFormula(name, a, b)
            return ModelResult(name, a, b, r, stdError, true, formula)

        } catch (e: Exception) {
            return ModelResult(name, 0.0, 0.0, 0.0, 0.0, false, "")
        }
    }

    private fun generateFormula(name: String, a: Double, b: Double): String {
        val signA = if (a >= 0) "" else "-"
        val signB = if (b >= 0) "+" else "-"
        val absA = abs(a)
        val absB = abs(b)

        return when (name) {
            "Lineal" -> "Y = $signA${format(absA)} $signB ${format(absB)} * X"
            "1/X"    -> "Y = $signA${format(absA)} $signB ${format(absB)} / X"
            "LOG(X)" -> "Y = $signA${format(absA)} $signB ${format(absB)} * LOG(X)"
            "SQR(X)" -> "Y = $signA${format(absA)} $signB ${format(absB)} * SQR(X)"
            "EXP(X)" -> "Y = $signA${format(absA)} $signB ${format(absB)} * EXP(X)"
            "X^2"    -> "Y = $signA${format(absA)} $signB ${format(absB)} * X^2"
            else     -> ""
        }
    }

    private fun format(value: Double): String {
        return String.format("%.4f", value).replace(",", ".")
    }
    // ============================================
    // PREDICCIÓN DE Y DADO X
    // ============================================
    fun predictY(model: ModelResult, x: Double): Double {
        return when (model.name) {
            "Lineal" -> model.a + model.b * x
            "1/X"    -> if (x == 0.0) Double.NaN else model.a + model.b / x
            "LOG(X)" -> if (x <= 0.0) Double.NaN else model.a + model.b * ln(x)
            "SQR(X)" -> if (x < 0.0) Double.NaN else model.a + model.b * sqrt(x)
            "EXP(X)" -> if (x > 45 || x < -45) Double.NaN else model.a + model.b * exp(x)
            "X^2"    -> model.a + model.b * x * x
            else     -> Double.NaN
        }
    }
    fun predictX(model: ModelResult, y: Double): Double {
        return when (model.name) {
            "Lineal" -> (y - model.a) / model.b
            "1/X"    -> model.b / (y - model.a)
            "LOG(X)" -> exp((y - model.a) / model.b)
            "SQR(X)" -> ((y - model.a) / model.b).pow(2)
            "EXP(X)" -> ln((y - model.a) / model.b)
            "X^2"    -> sqrt((y - model.a) / model.b)
            else     -> Double.NaN
        }
    }

    // ============================================
    // LECTURA DE ARCHIVO EXCEL (.xlsx)
    // ============================================
    fun readExcelFile(inputStream: java.io.InputStream): List<DataPoint> {
        val dataList = mutableListOf<DataPoint>()
        try {
            val workbook = org.apache.poi.xssf.usermodel.XSSFWorkbook(inputStream)
            val sheet = workbook.getSheetAt(0)

            for (row in sheet) {
                if (row == null) continue

                val cellA = row.getCell(0)
                val cellB = row.getCell(1)

                val x = when (cellA?.cellType) {
                    org.apache.poi.ss.usermodel.CellType.NUMERIC -> cellA.numericCellValue
                    org.apache.poi.ss.usermodel.CellType.STRING ->
                        cellA.stringCellValue.trim().replace(',', '.').toDoubleOrNull()
                    else -> null
                }

                val y = when (cellB?.cellType) {
                    org.apache.poi.ss.usermodel.CellType.NUMERIC -> cellB.numericCellValue
                    org.apache.poi.ss.usermodel.CellType.STRING ->
                        cellB.stringCellValue.trim().replace(',', '.').toDoubleOrNull()
                    else -> null
                }

                if (x != null && y != null) {
                    dataList.add(DataPoint(x, y))
                }
            }

            workbook.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return dataList
    }

    // ============================================
    // GUARDAR ANÁLISIS COMPLETO EN CSV
    // ============================================
    fun saveAnalysisToCsv(
        context: android.content.Context,
        dataPoints: List<DataPoint>,
        results: List<ModelResult>,
        predictions: List<Prediction> = emptyList()
    ): String? {
        try {
            // Nombre del archivo con fecha y hora
            val timestamp = java.text.SimpleDateFormat(
                "yyyy-MM-dd_HH-mm",
                java.util.Locale.getDefault()
            ).format(java.util.Date())
            val fileName = "DataFit_analisis_$timestamp.csv"

            // Separador para Excel en español (punto y coma)
            val SEP = ";"

            // Contenido del CSV
            val sb = StringBuilder()

            // ---------- SECCIÓN 1: DATOS INGRESADOS ----------
            sb.appendLine("DATOS INGRESADOS")
            sb.appendLine("X${SEP}Y")
            dataPoints.forEach { p ->
                sb.appendLine("${p.x}${SEP}${p.y}")
            }
            sb.appendLine()

            // ---------- SECCIÓN 2: MODELO GANADOR ----------
            val winner = results.firstOrNull { it.isValid }
            if (winner != null) {
                val rSquared = winner.r * winner.r * 100
                sb.appendLine("MODELO GANADOR")
                sb.appendLine("Modelo${SEP}${winner.name}")
                sb.appendLine("Ecuacion${SEP}\"${winner.formula}\"")
                sb.appendLine("A (Intercepto)${SEP}${String.format("%.4f", winner.a)}")
                sb.appendLine("B (Pendiente)${SEP}${String.format("%.4f", winner.b)}")
                sb.appendLine("R (Correlacion)${SEP}${String.format("%.4f", winner.r)}")
                sb.appendLine("R2 (Varianza %)${SEP}${String.format("%.2f", rSquared)}")
                sb.appendLine("Error Estandar${SEP}${String.format("%.4f", winner.error)}")
                sb.appendLine()

                // ---------- SECCIÓN 3: PREDICCIONES ----------
                sb.appendLine("PREDICCIONES DEL MODELO GANADOR")
                sb.appendLine("X${SEP}Y observado${SEP}Y calculado${SEP}Residuo")
                dataPoints.forEach { p ->
                    val yCalc = predictY(winner, p.x)
                    val residual = p.y - yCalc
                    sb.appendLine(
                        "${p.x}${SEP}${p.y}${SEP}" +
                                "${String.format("%.4f", yCalc)}${SEP}" +
                                "${String.format("%+.4f", residual)}"
                    )
                }
                sb.appendLine()
                // ---------- SECCIÓN 4: PREDICCIONES PERSONALIZADAS DEL USUARIO ----------
                if (predictions.isNotEmpty()) {
                    sb.appendLine("PREDICCIONES PERSONALIZADAS DEL USUARIO")
                    sb.appendLine("Tipo${SEP}Entrada${SEP}Salida")
                    predictions.forEach { pred ->
                        sb.appendLine(
                            "${pred.tipo}${SEP}" +
                                    "${String.format("%.4f", pred.entrada)}${SEP}" +
                                    "${String.format("%.4f", pred.salida)}"
                        )
                    }
                    sb.appendLine()
                }
                // ---------- SECCIÓN 4: COMPARATIVA DE TODOS LOS MODELOS ----------
                sb.appendLine("COMPARATIVA DE TODOS LOS MODELOS")
                sb.appendLine("Modelo${SEP}A${SEP}B${SEP}R")
                results.forEach { m ->
                    if (m.isValid) {
                        sb.appendLine(
                            "${m.name}${SEP}" +
                                    "${String.format("%.4f", m.a)}${SEP}" +
                                    "${String.format("%.4f", m.b)}${SEP}" +
                                    "${String.format("%.4f", m.r)}"
                        )
                    }
                }
            }

            // ============================================
            // GUARDAR SEGÚN LA VERSIÓN DE ANDROID
            // ============================================
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                // Android 10 o superior: usar MediaStore
                val contentValues = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(
                        android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_DOWNLOADS
                    )
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(
                    android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    contentValues
                )

                uri?.let {
                    resolver.openOutputStream(it)?.use { outputStream ->
                        outputStream.write(sb.toString().toByteArray())
                    }
                    return fileName
                }
            } else {
                // Android 9 o inferior: usar File API clásica
                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_DOWNLOADS
                )
                val file = java.io.File(downloadsDir, fileName)
                file.writeText(sb.toString())
                return fileName
            }

            return null
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}


